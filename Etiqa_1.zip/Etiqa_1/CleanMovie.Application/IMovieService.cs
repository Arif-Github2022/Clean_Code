﻿using CleanMovie.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CleanMovie.Application;


namespace CleanMovie.Application
{
    private List<Movie> GetMovies();
    //public Movie GetMovieDetail(string MovieName);
}

