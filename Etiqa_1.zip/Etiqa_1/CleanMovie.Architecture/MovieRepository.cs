﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CleanMovie.Application

namespace CleanMovie.Architecture
{
    public class MovieRepository: IMovieRepository
    {
        public static List<Movie> Movies = new List<Movie>();
    }
}
