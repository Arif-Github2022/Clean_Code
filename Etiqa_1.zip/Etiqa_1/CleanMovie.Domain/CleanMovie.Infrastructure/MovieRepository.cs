﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CleanMovie.Application;
using CleanMovie.Domain;

namespace CleanMovie.Infrastructure
{
    public class MovieRepository: IMovieRepository
    {
        public static List<Movie> movies = new List<Movie>()
        {
            new Movie{Id=1,Name="Abc",Cost=3 },
            new Movie{Id=2,Name="Hello",Cost=5 },

        };
        public List<Movie> AllMovie()   
        {
           return movies;
        }

        public Movie GetMovieDetail(int id)
        {
            var movie = movies.Find(x => x.Id == id);
            return movie;
        }

        public string DeleteMovie(int id)
        {
            movies.RemoveAll(x => x.Id == id);
            return "Remove Successully";
        }

        public string InsertMovie(Movie movieDetail)
        {
            movies.Add(movieDetail);
            AllMovie();
            return "Movie Added";
        }
    }
}
