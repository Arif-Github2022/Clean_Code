﻿namespace CleanMovie.Api.RequestModel
{
    public class DeleteMovieByIdRequest
    {
        public int Id { get; set; }
    }
}
