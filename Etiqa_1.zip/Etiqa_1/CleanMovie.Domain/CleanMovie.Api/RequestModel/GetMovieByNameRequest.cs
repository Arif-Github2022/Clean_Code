﻿namespace CleanMovie.Api.RequestModel
{
    public class GetMovieByNameRequest
    {
        public string? Name { get; set; }
    }
}
