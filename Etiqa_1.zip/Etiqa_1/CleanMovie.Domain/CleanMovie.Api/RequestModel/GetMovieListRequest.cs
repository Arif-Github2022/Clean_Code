﻿namespace CleanMovie.Api.RequestModel
{
    public class GetMovieListRequest
    {
        
    }
}
