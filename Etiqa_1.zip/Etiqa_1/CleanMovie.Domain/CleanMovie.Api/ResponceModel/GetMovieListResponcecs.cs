﻿namespace CleanMovie.Api.ResponceModel
{
    public class GetMovieListResponcecs
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public decimal? Cost { get; set; }
    }
}
