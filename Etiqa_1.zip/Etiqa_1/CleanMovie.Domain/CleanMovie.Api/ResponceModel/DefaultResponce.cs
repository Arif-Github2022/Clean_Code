﻿namespace CleanMovie.Api.ResponceModel
{
    public class DefaultResponce
    {
        public string? msg { get; set; }

    }
}
