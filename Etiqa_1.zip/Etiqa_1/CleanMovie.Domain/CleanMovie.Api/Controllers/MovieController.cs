﻿using CleanMovie.Api.RequestModel;
using CleanMovie.Application;
using CleanMovie.Domain;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Net;
using CleanMovie.Infrastructure;


namespace CleanMovie.Api.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        private readonly ILogger<MovieController> _logger;
        private readonly IMovieService _service;
        public MovieController(IMovieService service, ILogger<MovieController> logger)
        {
            _logger = logger;
            _service = service;
        }
     
        [HttpGet("MovieList")]
        public ActionResult<List<Movie>> GetListOfMovie()
        {
            _logger.LogInformation("Searching started");
            var MovieList = _service.GetAllMovie();
            return Ok(MovieList);
        }


        [HttpGet("MovieDetail")]
        public ActionResult<Movie> MovieDetails(int MovieId)
        {
            _logger.LogInformation("Searching started");
            var MovieList = _service.MovieDetails(MovieId);
            return Ok(MovieList);
        }

      
        [HttpDelete("DeleteMovie")]
        public ActionResult DeleteMovie(int MovieId)
        {
            _logger.LogInformation("Searching started");
            var MovieList = _service.DeleteMovie(MovieId);
            return Ok("Movie Deleted");
        }

        //// PUT api/<MovieController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //    _logger.LogInformation("Updation started");
        //}

        // DELETE api/<MovieController>/5
        [HttpPost("InsertMovie")]
        public ActionResult InsertMovie(Movie mDetail)
        {
            _logger.LogInformation("Searching started");
            var MovieList = _service.InsertMovie(mDetail);
            return Ok("Movie Inserted");
        }
    }
}


    
